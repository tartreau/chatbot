module.exports = {
	Dialogflow: '676bcbd805734399903f12247cb3a6f6',
	Discord: 'NDAxNDExOTA3NzQ0OTU2NDE2.DUKRzQ.BofuHmUdkctmMH3H0b2nNf0Okzk'
}
