const API_KEY = '19a9a6b6100cc5793e256ef3d8b20e8a';
module.exports ={
  API_KEY
}
