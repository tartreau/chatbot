const TOKEN = 'NDAxNDExOTA3NzQ0OTU2NDE2.DUKRzQ.BofuHmUdkctmMH3H0b2nNf0Okzk';
module.exports ={
  TOKEN
}
